<?php

namespace app\models; // appel le repertoir Models

use PDO;

class Connexion extends Model
{
    private $id_membre;
    private $passWord;
    private $role;
    private $statut;
    private $email;



    public function getIdMembre() {
        return $this->idMembre;
    }

    public function getPassWord() {
        return $this->passWord;
    }

    public function getRole() {
        return $this->role;
    }

    public function getStatut() {
        return $this->statut;
    }

    public function getEmail() {
        return $this->email;
    }



    public function setId_Membre($id_Membre)
    {
        $this->id_Membre = $id_Membre;
        return $this;

    }
 
    public function setPassWordSexe($passWord)
    {
        $this->passWord = $passWord;
        return $this;

    }


    public function setRole($role)
    {
        $this->role = $role;
        return $this;

    }


    public function setStatut($statut)
    {
        $this->statut = $statut;
        return $this;

    }

  
    public function setEmail($email)
    {
        $this->email = $email;
        return $this;

    }


    public function listerConnexion()
    {
        return static::database()->query('SELECT * FROM connexion')
            ->fetchAll(PDO::FETCH_CLASS, __CLASS__);
    }

    public function createConnexion()
     {
        $sqlState = static::database()->prepare("INSERT INTO connexion VALUES(?,?,?,?,?)");
        return $sqlState->execute([

            $this->id_membre,
            $this->passWord,
            $this->role,
            $this->statut,
            $this->email,
          

        ]);
    }



    public function update($id)
    {
        $sqlState = static::database()->prepare("
            UPDATE patients
            SET 
                nom=?,
                prenom=?,
                daten=?,
                sexe=?,
                adresse=?,
                cp=?,
                fumeur=?
            WHERE id = ?
        ");
        return $sqlState->execute([
            $this->nom,
            $this->prenom,
            $this->daten,
            $this->sexe,
            $this->adresse,
            $this->cp,
            $this->fumeur,
            $id
        ]);
    }

    public function destroy($id)
    {
        $sqlState = self::database()->prepare("DELETE FROM connexion WHERE id = ?");
        return $sqlState->execute([$id]);
    }
}