<?php

namespace app\models; // appel le repertoir Models

use PDO;

class Membre extends Model{


    private $prenom;
    private $nom;
    private $email;
    private $sexe;
    private $date_naissance	;
    private $passWord;
    private $role;
    private $statut;




    public function getPrenom()
    {
        return $this->prenom;
    }

    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;
        return $this;

    }

    public function getNom()
    {
        return $this->nom;
    }

    public function setNom($nom)
    {
        $this->nom = $nom;
        return $this;

    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
        return $this;

    }

    public function getSexe()
    {
        return $this->sexe;
    }

    public function setSexe($sexe)
    {
        $this->sexe = $sexe;
        return $this;

    }

    public function getDnais()
    {
        return $this->date_naissance	;
    }

    public function setDnais($date_naissance	)
    {
        $this->date_naissance	 = $date_naissance	;
        return $this;

    }

    public function getPassWord()
    {
        return $this->passWord;
    }

    public function setPassWord($passWord)
    {
        $this->passWord = $passWord;
        return $this;

    }



    public function getStatut()
    {
        return $this->statut;
    }

    public function setStatut($statut)
    {
        $this->statut = $statut;
        return $this;

    }

    public function getRole()
    {
        return $this->role;
    }

    public function setRole($role)
    {
        $this->role = $role;
        return $this;

    }

    public function latest()
    {
        return static::database()->query('SELECT membres.*,connexion.* FROM membres JOIN connexion ON membres.id = connexion.id_membre order by id DESC')
            ->fetchAll(PDO::FETCH_CLASS, __CLASS__);
    }




    public static function getMembre($email)
    {
        $result = static::database()->query("SELECT * FROM membres WHERE email ='$email'");
        
        if($result){
            return current($result->fetchAll(PDO::FETCH_CLASS, __CLASS__));

        }else {
            return false ;
        }
    }


    public static function ConnexionMembre($email)
    {
        $result = static::database()->query("SELECT * FROM connexion WHERE email ='$email'");
        
        if($result){
            return current($result->fetchAll(PDO::FETCH_CLASS, __CLASS__));

        }else {
            return false ;
        }
    }


    public function createMembre()
    {
       $sqlState = static::database()->prepare("INSERT INTO membres VALUES(null,?,?,?,?,?)");
       return $sqlState->execute([

           $this->nom,
           $this->prenom,
           $this->email,
           $this->sexe,
           $this->date_naissance	

       ]);
    }    

    public function createConnexion(){
        $id_membre =static::database()->lastInsertId();

            $sqlState = static::database()->prepare("INSERT INTO connexion VALUES(?,?,?,?,?)");
            return $sqlState->execute([
                $id_membre,
                $this->passWord,
                $this->role,
                $this->statut,
                $this->email

      ]);
    }

 
    

    public static function view($id)
    {
        $sqlState = static::database()->prepare("SELECT * FROM membre WHERE id = ?");
        $sqlState->execute([
            $id
        ]);
        return current($sqlState->fetchAll(PDO::FETCH_CLASS, __CLASS__));
    }
/*
    public function update($id)
    {
        $sqlState = static::database()->prepare("
            UPDATE membre
            SET 
                nom=?,
                prenom=?,
                email=?,
                sexe=?,
                date_naissance	=?
              
            WHERE id = ?
        ");
        return $sqlState->execute([
            $this->nom,
            $this->prenom,
            $this->daten,
            $this->sexe,
            $this->adresse,
            $this->cp,
            $this->fumeur,
            $id
        ]);
    }*/

    public function destroy($id)
    {
        $sqlState = self::database()->prepare("DELETE FROM membre WHERE id = ?");
        return $sqlState->execute([$id]);
    }

    public function onStatut($id)
    {
        $sqlState = self::database()->prepare("UPDATE connexion SET statut = 'A' WHERE id_membre = ?");
        return $sqlState->execute([$id]);
    }
    public function offStatut($id)
    {
        $sqlState = self::database()->prepare("UPDATE connexion SET statut = 'I' WHERE id_membre = ?");
        return $sqlState->execute([$id]);
    }
}