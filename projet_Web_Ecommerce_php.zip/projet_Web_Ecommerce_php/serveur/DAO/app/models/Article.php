<?php

namespace app\models; // appel le repertoir Models

use PDO;



class Article extends Model
{
    private $categorie;
    private $nomArticle;
    private $description;
    private $prix;
    private $quantite;
    private $image;
    private $date_creation;

    private $reponse=array();


  /**
     * @param mixed $modele
     * @return Article
     */
    public function getCategorie() {
        return $this->categorie;
    }
     /**
     * @param mixed $modele
     * @return Article
     */

    public function getNomArticle() {
        return $this->nomArticle;
    }
     /**
     * @param mixed $modele
     * @return Article
     */

    public function getDescription() {
        return $this->description;
    }
     /**
     * @param mixed $modele
     * @return Article
     */

    public function getPrix() {
        return $this->prix;
    }
     /**
     * @param mixed $modele
     * @return Article
     */

    public function getQuantite() {
        return $this->quantite;
    }
     /**
     * @param mixed $modele
     * @return Article
     */

    public function getImage() {
        return $this->image;
    }
     /**
     * @param mixed $modele
     * @return Article
     */
    public function getDateCreation() {
        return $this->date_creation;
    }

    // Setters
 

    public function setCategorie($categorie) {
        $this->categorie = $categorie;
        return $this;

    }

    public function setNomArticle($nomArticle) {
        $this->nomArticle = $nomArticle;
        return $this;

    }

    public function setDescription($description) {
        $this->description = $description;
        return $this;

    }

    public function setPrix($prix) {
        $this->prix = $prix;
        return $this;

    }

    public function setQuantite($quantite) {
        $this->quantite = $quantite;
        return $this;

    }

    public function setImage($image) {
        $this->image = $image;
        return $this;

    }

    public function setDateCreation($date_creation) {
        $this->date_creation = $date_creation;
        return $this;

    }
 
    public function latest()
    {
        return static::database()->query('SELECT * FROM articles order by id DESC')
            ->fetchAll(PDO::FETCH_CLASS, __CLASS__);
    }


    public static function view($id)
    {
        $sqlState = static::database()->prepare("SELECT * FROM articles WHERE id = ?");
        $sqlState->execute([
            $id
        ]);
        return current($sqlState->fetchAll(PDO::FETCH_CLASS, __CLASS__));
    }
/*
    public function getArticleById($id)
    {
        $sqlState = self::database()->prepare("SELECT * FROM articles WHERE id = ?");
        $sqlState->execute([$id]);
        return current($sqlState->fetchAll(PDO::FETCH_CLASS,__CLASS__));
    }*/




    public function createArticle()
    {
       $sqlState = static::database()->prepare("INSERT INTO articles VALUES(null,?,?,?,?,?,?,?)");
       return $sqlState->execute([

           $this->categorie,
           $this->nomArticle,
           $this->description,
           $this->prix,
           $this->quantite,
           $this->image,
           $this->date_creation


       ]);
    } 

    

    public function updateArticle($id)
    {
        $sqlState = static::database()->prepare("
            UPDATE articles
            SET 
                categorie=?,
                nomArticle=?,
                description=?,
                prix=?,
                quantite=?,
                image=?,
                date_creation=?
            WHERE id = ?
        ");
        return $sqlState->execute([
            $this->categorie,
            $this->nomArticle,
            $this->description,
            $this->prix,
            $this->quantite,
            $this->image,
            $this->date_creation,
            $id
        ]);
    }

    public function destroyArticle($id)
    {
        $sqlState = self::database()->prepare("DELETE FROM articles WHERE id = ?");
        return $sqlState->execute([$id]);
    }

}

