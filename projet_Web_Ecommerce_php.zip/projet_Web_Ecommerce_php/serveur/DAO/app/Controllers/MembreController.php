<?php

namespace app\Controllers;
use app\models\Membre;


class MembreController extends BaseController
{
    /**
     * @return Article
     */
    public static function getModel()
    {
        if (is_null(static::$model)) {
            static::$model = new Membre();
        }
        return static::$model;
    }


    public static function indexAction()
    {
        // Modele ( Les donnees) les Membres
        $Membres = static::getModel()->latest();

        // View (afficher les données)
        static::view("gestionMembre", $Membres);
    }

    

    public static function createAction()
    {
        static::view('createMembre');
    }


    public static function storeAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['remail'];
            $Membres = static::getModel()->getMembre($email);
            if($Membres){
                $msg = "membre existe";

            }else{

                $created = static::getModel()
                    ->setNom($_POST['rname'])
                    ->setPrenom($_POST['rprenom'])
                    ->setEmail($email)
                    ->setSexe($_POST['sexe'])
                    ->setDnais($_POST['dnais'])
                    
                ->createMembre();
                if ($created === true) {
                    $createdConnexion = static::getModel()
                    ->setPassWord($_POST['passWord'])
                    ->setRole('M')
                    ->setStatut('A')
                    ->setEmail($_POST['remail'])
                    ->createConnexion();
                    if($createdConnexion === true){
                        $msg = "connexion+valide";

                    }
                    else{
                        $msg = "connexion+non+valide";


                    }
                // static::redirect('list');
                } else {
                    $msg = "Erreur+membre";

                }
                $msg ="membre+bien+enregistrer ";
                header('Location:index.php?action=connMembre&msg='.$msg);

                

            }
        }
    }

    public static function ConnexionAction()
    {
        static::view('connMembre');
    }

    public static function storeConnexion()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['cemail'];
            $conn = static::getModel()->ConnexionMembre($email);
            if($conn){

                if($_POST['cpassword'] == $conn->getPassWord()){

                    if($conn->getStatut() == 'A'){
                    
                        if($conn->getRole() == 'A'){
                            header('Location:roote.php');
                            exit();

                        }elseif($conn->getRole() == 'E'){
                            header('Location: employer.php');
                            exit();


                        }elseif($conn->getRole() == 'M'){
                            header('Location: pageMembre.php');
                                exit();

                        }
                    }else{
                        $msg = "votre+compte+n+est+pas+actif";
                    }
                }else{
                    $msg = "le+mot+de+passe+est+incorrecte";
                }

            }else{
                $msg = "le+courreil+est+incorrecte"; 
            }
            header('Location:index.php?action=connMembre&msg='.$msg);
            exit();

            
        }
    }




    public static function editAction()
    {
        static::view('edit', self::getModel()::view($_GET['id']));
    }

    public static function updateAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $updated = static::getModel()
                    ->setNom($_POST['nom'])
                    ->setPrenom($_POST['prenom'])
                    ->setDaten($_POST['daten'])
                    ->setSexe($_POST['sexe'])
                    ->setAdresse($_POST['adresse'])
                    ->setCp($_POST['cp'])
                    ->setFumeur($_POST['fumeur'])
                ->update($_POST['id']);
            if ($updated === true) {
                static::redirect('index.php?action=list');
            } else {
                $msg = "Erreur";
            }
        }
    }

    public static function destroyAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $deleted = static::getModel()
                ->destroy($_GET['id']);
            if ($deleted === true) {
                static::redirect('index.php?action=list');
            } else {
                $msg = "Erreur";
            }
        }
    }

    public static function StatutActionA()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $activer = static::getModel()
                ->onStatut($_GET['id']);
            
            if ($activer === true) {
                static::redirect('roote.php?action=gestionMembre');
            }else {
                $msg = "Erreur";
            }
        
        }
    }

    public static function StatutActionO()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $desactiver = static::getModel()
                ->offStatut($_GET['id']);
            
            if ($desactiver === true) {
                static::redirect('roote.php?action=gestionMembre');
            }else {
                $msg = "Erreur";
            }
        
        }
    }
}