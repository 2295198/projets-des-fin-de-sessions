<?php

namespace app\Controllers;
use app\models\Article;


class AdminController extends BaseController
{
   /**
     * @return Article
     */
    public static function getModel()
    {
        if (is_null(static::$model)) {
            static::$model = new Article();
        }
        return static::$model;
    }


    public static function adminAffiche()
    {
        // Modele ( Les donnees) les Articles
        $Articles = static::getModel()->latest();

        // View (afficher les données)
        static::view("gestionAdminArticle", $Articles);
    }

/*
    public static function getArticleByIdAction()
    {
    /* if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $finded = static::getModel()
                ->getArticleById($_POST['id']);
        }*/
       //return $article = static::getModel()->getArticleById($_POST['id']);
      //  static::view('getArticleById', self::getModel()::getArticleById($_POST['id'])); 

        // Vérifier si l'article existe
    
    //}
    
    public static function destroyAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $deleted = static::getModel()
                ->destroyArticle($_GET['id']);

            if ($deleted === true) {
                static::redirect('roote.php?action=gestionAdminArticle');
            } else {
                echo "Erreur";
            }
        }
    }


public static function storeArticleAction()
{
    $repPochettes = "serveur/pochettes/";
   // $nouveauNom = "avatar.png";
    $image = 'https://www.magazette.fr/wp-content/uploads/2017/02/fournitures-bureau-discount-1024x683.jpeg';
    $nom = $_POST['nomArticle'];


    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Vérifier si une photo a été envoyée
        if(isset($_FILES['pochette']) && $_FILES['pochette']['error'] == 0) {
            $tmpFic = $_FILES['pochette']['tmp_name'];
            $nomOriginal = $_FILES['pochette']['name'];
            $extension = strrchr($nomOriginal,'.');
            $nouveauNom = sha1($nom.time()).$extension;
            @move_uploaded_file($tmpFic,$repPochettes.$nouveauNom);
            $image = $repPochettes.$nouveauNom ;
        }
        $created = static::getModel()
            ->setCategorie($_POST['categorie'])
            ->setNomArticle($_POST['nomArticle'])
            ->setDescription($_POST['description'])
            ->setPrix($_POST['prix'])
            ->setQuantite($_POST['quantite'])
            ->setImage($image)
            ->setDateCreation($_POST['dateCreation'])
            ->createArticle();

        if ($created === true) {
            static::redirect('roote.php?action=gestionAdminArticle');
        } else {
            echo "Erreur";
        }
    }
}

public static function editAction()
    {
        //var_dump($id);
        $id = $_GET['id'];
        $article = self::getModel()::view($id);
        static::view('edit',$article);
    }


public static function updateAction()
{
   $repPochettes = "serveur/pochettes/";
   // $nouveauNom = "avatar.png";
    $image = 'https://www.magazette.fr/wp-content/uploads/2017/02/fournitures-bureau-discount-1024x683.jpeg';
    //$nom = $_POST['nomArticle'];
    //$article = static::getModel()->getArticleById($_POST['id']);


    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nom = $_POST['nomArticle'];

        // Vérifier si une photo a été envoyée
        if(isset($_FILES['pochette']) && $_FILES['pochette']['error'] == 0) {
            $tmpFic = $_FILES['pochette']['tmp_name'];
            $nomOriginal = $_FILES['pochette']['name'];
            $extension = strrchr($nomOriginal,'.');
            $nouveauNom = sha1($nom.time()).$extension;
            @move_uploaded_file($tmpFic,$repPochettes.$nouveauNom);
            $image = $repPochettes.$nouveauNom ;
        }

        $updated = static::getModel()
            ->setCategorie($_POST['categorie'])
            ->setNomArticle($_POST['nomArticle'])
            ->setImage($image)
            ->setDescription($_POST['description'])
            ->setPrix($_POST['prix'])
            ->setQuantite($_POST['quantite'])
            ->setDateCreation($_POST['dateCreation'])
            ->updateArticle($_POST['id']);
        if ($updated === true) {
            static::redirect('roote.php?action=gestionAdminArticle');
        } else {
            $msg= "erreur d enregistrement ";
        }
    }
}




}







