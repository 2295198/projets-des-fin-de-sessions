<?php

namespace app\Controllers;

use app\models\Article;


class ArticleController extends BaseController
{
    /**
     * @return Article
     */
    public static function getModel()
    {
        if (is_null(static::$model)) {
            static::$model = new Article();
        }
        return static::$model;
    }


    public static function indexAction()
    {
        // Modele ( Les donnees) les Articles
        $Articles = static::getModel()->latest();

        // View (afficher les données)
        static::view("list", $Articles);
    }

    

    public static function createAction()
    {
        static::view('create');
    }


    public static function storeAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $created = static::getModel()
               // $prenom;$nom;$email;$sexe;$dnais;

                ->setNom($_POST['nom'])
                ->setPrenom($_POST['prenom'])
                ->setEmail($_POST['email'])
                ->setSexe($_POST['sexe'])
                ->setDnais($_POST['dnais'])
                
            ->create();
            if ($created === true) {
                static::redirect('index.php?action=list');
            } else {
                echo "Erreur";
            }
        }
    }

    public static function editAction()
    {
        static::view('edit', self::getModel()::view($_GET['id']));
    }

    public static function updateAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $updated = static::getModel()
                    ->setNom($_POST['nom'])
                    ->setPrenom($_POST['prenom'])
                    ->setDaten($_POST['daten'])
                    ->setSexe($_POST['sexe'])
                    ->setAdresse($_POST['adresse'])
                    ->setCp($_POST['cp'])
                    ->setFumeur($_POST['fumeur'])
                ->update($_POST['id']);
            if ($updated === true) {
                static::redirect('index.php?action=list');
            } else {
                echo "Erreur";
            }
        }
    }

    public static function destroyAction()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $deleted = static::getModel()
                ->destroy($_GET['id']);
            if ($deleted === true) {
                static::redirect('index.php?action=list');
            } else {
                echo "Erreur";
            }
        }
    }
}