<?php

namespace app\Controllers;

class BaseController
{
    protected static $model;

    public static function view($view, $data = NULL)
    {
        require "serveur/DAo/resources/views/" . $view . ".php";
    }

    public static function redirect($route)
    {
        header("location:$route");
    }
}