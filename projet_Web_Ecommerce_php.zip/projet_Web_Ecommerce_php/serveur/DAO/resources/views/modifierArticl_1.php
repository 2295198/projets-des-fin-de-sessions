<?php
session_start();
require_once('../../Model.php');
/*
$requete= "SELECT DISTINCT categorie FROM articles";
$stmt = Connexion::getConnexion()->prepare($requete);
$stmt->execute();
$resultSet=$stmt->get_result();  */

global $cat,$nom,$description,$prix,$qte,$image,$date;  
$id=$_POST['id'];
$donnees= "SELECT * FROM articles WHERE id=$id ";
try{

$stmt = Connexion::getModel()->prepare($donnees);
$stmt->execute();
$donneesSet=$stmt->get_result();
foreach($donneesSet as $donnee){
$cat=$donnee['categorie'];
$nom=$donnee['nomArticle'];
$description=$donnee['description'];
$prix=$donnee['prix'];
$qte=$donnee['quantite'];
$image=$donnee['image'];

}

}
catch(EXception $e){
    echo $e;
}
finally{
 
}

?>



<table>

<section class="vh-100" style="background-color: fff;">
<div class="container py-5 h-100">
<div class="row d-flex justify-content-center align-items-center h-100">
<div class="col col-xl-10">
<div class="card" style="border-radius: 1rem;">
  <div class="row g-0">
    <div class="col-md-6 col-lg-6 d-none d-md-block">
        <br><br>
        <img src="../client/images/Fournitures-de-bureau.png" alt=""  width=450px height=480px>

    </div>
    <div class="col-md-4 col-lg-5 d-flex align-items-center">
      <div class="card-body p-4 p-lg-5 text-black">


          <div class="d-flex align-items-center mb-3 pb-1">



          <div >


    <form id="editArticleModal" action="../../DAO/app/Controllers/AdminControler.php?action=updateArticle" method="POST" enctype="multipart/form-data" onSubmit=";">

    <h3 class="mb-5"></h3>
    <div class="form-outline mb-4">
    <label class="label-control" for="id">id</label>
      <input type="hidden"  class="form-control form-control-lg" id="id"  name="id"  required />
    </div>
    <div class="form-outline mb-4">
    <label class="label-control" for="categorie">Categorie</label>
      <input type="text"  class="form-control form-control-lg" id="categorie"  name="categorie"  required />
    </div>
    <div class="form-outline mb-4">
    <label class="label-control" for="nomArticle">Nom d'article</label>
      <input type="text"  class="form-control form-control-lg" id="nomArticle"  name="nomArticle"  required />
    </div>

    <div class="form-outline mb-4">



      <label class="form-label" for="prix">Prix: (en $)</label>
      <input type="number" step="0.01" class="form-control" id="prix" name="prix" placeholder="" value="" required>


    </div>
    
    <div class="form-outline mb-4">
    <label for="Quantite" class="form-label">Quantite</label>
    <input type="text" class="form-control is-valid" id="Quantite"  name = "Quantite" value="" required>

    </div>
    
    <div class="form-outline mb-4">
    <label for="dateC" class="form-label">Date de creation</label>
    <input type="text" class="form-control is-valid" id="dateC" name="dateC" value="" required>
    </div>

    <div class="form-outline mb-4">
    <label for="description">description<span class="blue"></span></label>
    <textarea id="description" name="description" class="form-control" placeholder="" rows="4" ></textarea>
      <span id="setError"></span> 

    </div>

    <div class="form-outline mb-4">
    <label class="form-label" for="image">Sélectionner une image:</label>
    <input type="file" id="image" name="image"> 
      <span id="setError"></span> 

    </div>

  <p><br>
    <button class="btn btn-dark btn-lg " style="color:0fff" type="submit" >Envoyer</button>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <button  class="btn btn-dark btn-lg " style="color:red" type="reset">Vider</button>   
    </p>

  
    </form>
    
          
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>

</table>


<?php
$content = ob_get_clean();
include_once 'layoutAdmine.php';