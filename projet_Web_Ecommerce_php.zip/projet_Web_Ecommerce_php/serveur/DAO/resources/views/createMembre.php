

<?php
$title = "";
ob_start();
?>

<?php
  $msg="";
  if(isset($_GET['msg'])){
      $msg = $_GET['msg'];
  }
?>

<!doctype html>
<html lang="en">

        

</head>
<body>


    </head>


				<!-- MAIN HEADER -->
        <div id="header">

<!-- LOGO -->
<div class="col-md-3">
        <div class="header-logo">
          <a href="#" class="logo">
            <img src="client/images/logoCompagnie.png" alt="" width=250px height=80px>
          </a>
        </div>
      </div>
      <!-- /LOGO -->
  <!-- container --> <center>
            <p><h1 style="color:#f4f0ec";>Devenir membre...... c'est facile </h1></p>

  <div class="container">
    <!-- row -->
    <div class="row">

    </div>
    <!-- row -->
  </div>
  <!-- container -->
</div>
<!-- /MAIN HEADER -->
</header>
<!-- /HEADER -->
		<!-- /HEADER -->
        <section class="vh-100" style="background-color: #D3D3D3">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
          <div class="row g-0">
            <div class="col-md-8 col-lg-7 d-none d-md-block">
                
                <p > 
                  <br><br><br><br><br>
               <h4>
        Inscrivez-vous pour avoir un compte Vous n'êtes </h4><h4>qu'à quelques clics d'utiliser la première application </h4><h4>de 
        fourniture de bureau .</h4><h4> Remplissez le formulaire pour obtenir votre compte </h4><h4>personnel et faire vos achats facilement
        </h4>

       <br><br>

       <h3> Nouvel usager</h3>
       <li>Voici quelques-uns des nombreux avantages d’avoir un compte usager :</li>

        <li>Consultez les détails de vos commandes</li>
        <li>Créez vos propres listes de produits favoris</li>
        <li>Suivez l’état de vos commandes</li>
        <li>Enregistrez vos adresses d’expédition</li>
        <li>Effectuez des retours de marchandises en ligne</li>
                </p>

            </div>
            <div class="col-md-2 col-lg-5 d-flex align-items-center">
              <div class="card-body p-4 p-lg-9 text-black">





                  <div >
            <form id="Contactform" action="index.php?action=store" method="POST" enctype="multipart/form-data" onSubmit="return verifierMdp();">
            <h3 class="mb-5"></h3>
            <div class="form-outline mb-6">
            <label class="label-control" for="rprenom">Prénom</label>
              <input type="text"  class="form-control form-control-lg" id="rprenom"  name="rprenom"  />
            </div>

            <div class="form-outline mb-6">
            <label class="label-control" for="rname">Nom</label>
              <input type="text"  class="form-control form-control-lg" id="rname" name="rname" />
            </div>
            
            <div class="form-outline mb-6">
            <label class="form-label" for="remail">Email</label>
              <input type="email" class="form-control form-control-lg" id="remail" name="remail"  />
              <span  class="text-danger" > <?= $msg  ?> </span> 
            </div>
            
       
            <div class="form-outline mb-6">
            <span id="info">Pour des raisons statistiques</span>
            <div class="form-check">
                <input class="form-check-input" type="radio" value="F" name="sexe" id="fm">
                <label class="form-check-label" for="fm">
                    Femme
                </label>
                </div>
                <div class="form-check">
            
                <input class="form-check-input" type="radio" value="H" name="sexe" id="hm">
                <label class="form-check-label" for="hm">
                    Homme
                </label>
                </div>
                <div class="form-check">
            
                <input class="form-check-input" type="radio" value="A" name="sexe" id="au">
                <label class="form-check-label" for="au">
                    Autre
                </label>
            </div>
            <br>
            <label class="form-label" for="dnais"> date de naissance </label>
              <input type="date" class="form-control form-control-lg" id="dnais" name="dnais"  />
            </div>

            <div class="form-outline mb-6">
            <label class="form-label" for="passWord"> Mot de passe </label>
              <input type="password" class="form-control form-control-lg" id="passWord" name="passWord"  />
              <span   class="text-danger" id="setError"></span> 

            </div>

            <div class="form-outline mb-6">
            <label class="form-label" for="cpass"> Confirmer le mot de passe </label>
              <input type="password"  class="form-control form-control-lg" id="cpass" name="cpass"  />
              <span  class="text-danger" id="setError"></span> 

            </div>

          <p><br>
            <button  class="button3 " type="submit" >Enregistrer</button>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button  class="btn btn-dark btn-lg " style="color: #F90528;" type="reset">Vider</button>   
            </p>


                      <p class="mb-5 pb-lg-2" style="color: #393f81;">Je suis client et j'ai un compte <a href="index.php?action=connMembre"
                      style="color: #393f81;">Connectez vous </a></p>



                      </form>
                  
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</section>

<?php
$content = ob_get_clean();
include_once 'layout.php';

















