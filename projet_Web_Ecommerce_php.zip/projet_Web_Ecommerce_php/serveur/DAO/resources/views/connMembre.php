   
<?php
$title = "";
ob_start();
?>

<?php
  $msg="";
  if(isset($_GET['msg'])){
      $msg = $_GET['msg'];
  }
?>


<section class="vh-100" style="background-color: 	#E0E0E0;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
            <div class="col-md-6 col-lg-5 d-none d-md-block">
                <br>
                <img src="client/images/logoCompagnie.png" alt=""  width=430px height=350px>

            </div>
            <div class="col-md-6 col-lg-7 d-flex align-items-center">
              <div class="card-body p-4 p-lg-5 text-black">


                  <div class="d-flex align-items-center mb-3 pb-1">



                  </div>

                        <br><br><br><br><br><br>
                        <form method="POST" action="index.php?action=storeConnexion">
                          <div  id= 'msg' style = 'visibility: visible'>
                        <span class="text-danger" > <?= $msg  ?> </span>  </div>

                        <script type="text/javascript">
                          function hideMsg(){
                            document.getElementById("msg").style.visibility = 'hidden'    ;
                                             }
                                             setTimeout('hideMsg()',5000) ;
                        </script>

                      
                        <br><br>

                  <div class="form-outline mb-4">
                  <input type="email" class="form-control is-valid" id="cemail" name="cemail" required>
                    <label class="form-label" for="cemail">Email address</label>
                  </div>

                  <div class="form-outline mb-4">
                  <input type="password" class="form-control is-valid" id="cpassword" name="cpassword" required>
                    <label class="form-label" for="cpassword">Password</label>
                  </div>
                        <br>
                  <div >
                    <button class="button2" value="Connexion" name="connexion" type="submit">Login</button>
                  </div>

                  <br><br>

                  <p class="mb-5 pb-lg-2" style="color: #F90528;">Vous n'avez pas de compte ? <a href="index.php?action=createMembre"
                      style="color: #F90528;">Inscrivez-vous ici </a></p>
                  
                      </form>



                      
<?php
$content = ob_get_clean();
include_once 'layout.php';
