<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		


		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

		<!-- Bootstrap -->




    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> +021-95-51-84</a></li>
						<li><a href="#"><i class="fa fa-envelope-o"></i> ben.noured@gmail.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> 2050 rue pie 9</a></li>
					</ul>
					<ul class="header-links pull-right">
					<li class="nav-item"><a href="roote.php?action=gestionAdminArticle">ACCEUIL</a></li>

					<li class="nav-item"><a href="roote.php?action=gestionAdminArticle"><i i class="fa fa-user-o" ></i> Voir Articles</a></li>

						<li class="nav-item"><a href="roote.php?action=gestionMembre"><i class="fa fa-user-o" ></i> Voir Membre</a></li>
						
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=deconnexion" >DECONNEXION</a>

                    </li>
					</ul>
			</div>



						
	


	</body>