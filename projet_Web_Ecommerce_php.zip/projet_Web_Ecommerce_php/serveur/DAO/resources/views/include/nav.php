<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<!--
		<title>Papier Bureau - </title>

		<link rel="stylesheet" href="client/css/style.css">
		<link rel="stylesheet" href="client/css/style1.css">
		<link rel="stylesheet" href="client/css/style2.css">

		<link rel="stylesheet" href="client//utilitaires copy/bootstrap-5.1.3-dist/css/bootstrap.min.css">
		<script src="client/utilitaires copy/jquery-3.6.0.min.js"></script>
		<script src="client/utilitaires copy/bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
		<script src="client/js/monjs.js"></script> -->

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="client/css/bootstrap.min.css"/>

		<!-- Slick -->
		<link type="text/css" rel="stylesheet" href="client/css/slick.css"/>
		<link type="text/css" rel="stylesheet" href="client/css/slick-theme.css"/>

		<!-- nouislider -->
		<link type="text/css" rel="stylesheet" href="client/css/nouislider.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="client/css/font-awesome.min.css">



    </head>
	<body>
		<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> +021-95-51-84</a></li>
						<li><a href="#"><i class="fa fa-envelope-o"></i> ben.noured@gmail.com</a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> 2050 rue pie 9</a></li>
					</ul>
					<ul class="header-links pull-right">
					<li class="nav-item"><a href="index.php?action=list">ACCEUIL</a></li>

					<li class="nav-item"><a href="index.php?action="><i class="fa fa-envelope-o"></i> CONTACTER NOUS</a></li>

						<li class="nav-item"><a href="index.php?action=createMembre"><i class="fa fa-user-o" ></i> DEVENIR MEMBRE</a></li>
						
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=connMembre" >CONNEXION</a>

                    </li>
					</ul>
			</div>



		<!--				
		<script src="client/js/jquery.min.js"></script>
		<script src="client/js/bootstrap.min.js"></script>
		<script src="client/js/slick.min.js"></script>
		<script src="client/js/nouislider.min.js"></script>
		<script src="client/js/jquery.zoom.min.js"></script>
		<script src="client/js/main.js"></script>
-->
	</body>
