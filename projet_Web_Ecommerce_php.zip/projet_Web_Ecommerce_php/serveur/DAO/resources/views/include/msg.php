<div class="toast-container posToast">
    <div id="toast" class="toast  align-items-center text-white bg-danger border-0" data-bs-autohide="false" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="toast-header">
        <img src="client/images/message.png" width=24 height=24 class="rounded me-2" alt="message">
        <strong class="me-auto">Messages</strong>
        <small class="text-muted"></small>
        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div id="textToast" class="toast-body">
        </div>