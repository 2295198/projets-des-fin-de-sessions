<?php
$title = "";
ob_start();
?>

<?php
  $msg="";
  if(isset($_GET['msg'])){
      $msg = $_GET['msg'];
  }
?>

<html lang="fr">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>Papier Bureau - </title>
		<link rel="stylesheet" href="../client//utilitaires copy/bootstrap-5.1.3-dist/css/bootstrap.min.css">
		<script src="../client/utilitaires copy/jquery-3.6.0.min.js"></script>
		<script src="../client/utilitaires copy/bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
		<script src="../client/js/monjs.js"></script>

		


		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="../client/css/bootstrap.min.css"/>

		<!-- Slick -->
		<link type="text/css" rel="stylesheet" href="../client/css/slick.css"/>
		<link type="text/css" rel="stylesheet" href="../client/css/slick-theme.css"/>

		<!-- nouislider -->
		<link type="text/css" rel="stylesheet" href="../client/css/nouislider.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="../client/css/font-awesome.min.css">

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="../client/css/style.css"/>
		<link type="text/css" rel="stylesheet" href="../client/css/style2.css"/>



       

    </head>



			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container --> <center>
                  <p><h1 style="color:#f4f0ec";>Ajouter un article</h1></p>
				  
 
				<div class="container">
					<!-- row -->
					<div class="row">
						


  
        </div>
        <!-- row -->
        </div>
        <!-- container -->
        </div>
        <!-- /MAIN HEADER -->
     

      <table>

        <section class="vh-100" style="background-color: fff;">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col col-xl-10">
        <div class="card" style="border-radius: 1rem;">
          <div class="row g-0">
            <div class="col-md-6 col-lg-6 d-none d-md-block">
                <br><br>
                <img src="client/images/Fournitures-de-bureau.png" alt=""  width=450px height=480px>

            </div>
            <div class="col-md-4 col-lg-5 d-flex align-items-center">
              <div class="card-body p-4 p-lg-5 text-black">


                  <div class="d-flex align-items-center mb-3 pb-1">



                  <div >


            <form id="" action="roote.php?action=store" method="POST" enctype="multipart/form-data" onSubmit=";">

            <h3 class="mb-5"></h3>
            <div class="form-outline mb-4">
            <label class="label-control" for="nomArticle">Nom d'article</label>
              <input type="text"  class="form-control form-control-lg" id="nomArticle"  name="nomArticle"  required />
            </div>

            <div class="form-outline mb-4">
   


              <label class="form-label" for="prix">Prix: (en $)</label>
              <input type="number" step="0.01" class="form-control" id="prix" name="prix" placeholder="" value="" required>


            </div>
            
            <div class="form-outline mb-4">
            <label for="Quantite" class="form-label">Quantite</label>
            <input type="text" class="form-control is-valid" id="Quantite"  name = "Quantite" value="" required>

            </div>
            
            <div class="form-outline mb-4">
            <label for="dateC" class="form-label">Date de creation</label>
            <input type="text" class="form-control is-valid" id="dateC" name="dateC" value="" required>
            </div>

            <div class="form-outline mb-4">
            <label for="description">description<span class="blue"></span></label>
            <textarea id="description" name="description" class="form-control" placeholder="" rows="4" ></textarea>
              <span id="setError"></span> 

            </div>

            <div class="form-outline mb-4">
            <label class="form-label" for="imageArt">Sélectionner une image:</label>
            <input type="file" id="imageArt" name="imageArt"> 
              <span id="setError"></span> 

            </div>

          <p><br>
            <button class="btn btn-dark btn-lg " style="color:0fff" type="submit" >Envoyer</button>   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <button  class="btn btn-dark btn-lg " style="color:red" type="reset">Vider</button>   
            </p>

          
            </form>
            
                  
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</table>

<?php
$content = ob_get_clean();
include_once 'layoutroote.php';
