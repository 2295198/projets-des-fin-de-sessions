
<?php
$title = "";
ob_start();
?>
		


<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->
</head>
<body>
<div class="container-xl">
	<div class="table-responsive">
		<div class="table-wrapper">
			<div class="table-title">
				<div class="row">
					<div class="col-sm-6">
						<h2>Gérer  <b>les Membre</b></h2>
					</div>
					<div class="col-sm-6">
						<a href="#addArticleModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Ajouter un nouveau Membre</span></a>
						<a href="#deleteArticleModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Supprimer un Membre</span></a>						
					</div>
				</div>
			</div>
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						
						<th><h4>Id</h4></th>
						<th><h4>Nom</h4></th>
						<th><h4>Prenom</h4></th>
            <th><h4>Email </h4> </th>
						<th><h4>Statut</h4></th>
						<th><h4>Date de naissance	</h4></th>
						<th><h4>Actions</h4></th>
					</tr>
				</thead>
				<tbody>
				<?php 
					foreach($data as $membre): ?>
					<tr>
						
                    <td style ="font-size:14px"><?= $membre->getId() ?></td>
						

						<td style ="font-size:13px"><?= $membre->getNom() ?></td>
						<td style ="font-size:13px"><?= $membre->getPrenom() ?></td>
						<td style ="font-size:13px"><?= $membre->getEmail() ?></td>
						<td style ="font-size:13px"><?= $membre->getStatut() ?></td>
						<td style ="font-size:13px"><?= $membre->getDnais() ?></td>
						
						<td>

						<!-- <a class="edit" data-toggle="modal" data-target="#editArticleModal" data-id="roote.php?action=updateArticle&id=<//?php echo $article->getId() ?>"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a> --> 
            <a type="button" class=" btn-success"  data-toggle="modal" data-target="#myModalA" data-article-id="<?php echo $membre->getId() ?>"><i class="material-icons" >&#xe909; </i></a>

  


            <a type="button" class=" btn-danger"  data-toggle="modal" data-target="#myModalI" data-article-id="<?php echo $membre->getId() ?>"><i class="material-icons">&#xe834;</i></a>


<!-- Fenêtre modale -->
<div class="modal fade" id="myModalA" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Activer le statut du membre</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Êtes-vous sûr de vouloir Activer cette Membre ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
        <a href="#" class="btn btn-success btn-ok">Activer</a>
      </div>
    </div>
  </div>
</div>

<!-- Fenêtre modale -->
<div class="modal fade" id="myModalI" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Activer le statut du membre</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>Êtes-vous sûr de vouloir Desactiver cette Membre ?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
        <a href="#" class="btn btn-danger btn-ok">desactiver</a>
      </div>
    </div>
  </div>
</div>







							
					</td>
					</tr>
				
					<?php endforeach ;?>				
					
				</tbody>
			</table>
			
	</div>        
</div>



<!-- Modal de confirmation -->
<div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog" aria-labelledby="confirmationModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="confirmationModalLabel">Confirmation</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Êtes-vous sûr de vouloir activer/désactiver ce membre?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
        <button type="button" class="btn btn-primary" id="confirmButton">Confirmer</button>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function() {
  $('input[name="options"]').click(function() {
    if ($('#option1').is(':checked')) {
      $('#confirmationModal').modal('show'); // afficher la modal pour activer le membre
      $('#confirmButton').click(function() {
        // le code pour activer le membre va ici
        $('#confirmationModal').modal('hide'); // masquer la modal
      });
    } else {
      $('#confirmationModal').modal('show'); // afficher la modal pour désactiver le membre
      $('#confirmButton').click(function() {
        // le code pour désactiver le membre va ici
        $('#confirmationModal').modal('hide'); // masquer la modal
      });
    }
  });
});
</script>




<?php
$content = ob_get_clean();
include_once 'layoutAdmine.php';



