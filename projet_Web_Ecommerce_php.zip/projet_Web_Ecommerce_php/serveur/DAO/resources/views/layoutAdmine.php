<?php
   
    $msg="";
    if(isset($_GET['msg'])){
        $msg = $_GET['msg'];
    }
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    		<title>Papier Bureau - </title>
		<link rel="stylesheet" href="client/css/style.css">
		<link rel="stylesheet" href="client/css/style1.css">
		<link rel="stylesheet" href="client/css/style2.css">
		<link rel="stylesheet" href="client//utilitaires copy/bootstrap-5.1.3-dist/css/bootstrap.min.css">
		<script src="client/utilitaires copy/jquery-3.6.0.min.js"></script>
		<script src="client/utilitaires copy/bootstrap-5.1.3-dist/js/bootstrap.min.js"></script>
		<script src="client/js/monjs.js"></script>

		


		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="client/css/bootstrap.min.css"/>

		<!-- Slick -->
		<link type="text/css" rel="stylesheet" href="client/css/slick.css"/>
		<link type="text/css" rel="stylesheet" href="client/css/slick-theme.css"/>

		<!-- nouislider -->
		<link type="text/css" rel="stylesheet" href="client/css/nouislider.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="client/css/font-awesome.min.css">

        

</head>
<body  onLoad = "initialiser(<?="'".$msg."'"  ?>);"> 

<?php require_once 'include/navAdmine.php'?>




<div class="container mt-2">
    
    <?= $content ?>
</div>

<?php require ('include/msg.php') ?>

		<script src="client/js/jquery.min.js"></script>
		<script src="client/js/bootstrap.min.js"></script>
		<script src="client/js/slick.min.js"></script>
		<script src="client/js/nouislider.min.js"></script>
		<script src="client/js/jquery.zoom.min.js"></script>
		<script src="client/js/main.js"></script>
		<script src="client/membre/viewMembre.js"></script>
		<script src="client/js/global.js"></script>


		

</body>
</html>


